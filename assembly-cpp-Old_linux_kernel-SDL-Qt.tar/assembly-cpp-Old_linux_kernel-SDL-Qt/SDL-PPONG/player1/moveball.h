#ifndef MOVEBALL_H
#define MOVEBALL_H

#define BDIRECTION     2

Uint32 MoveBall(Uint32 interval, void * data);

#endif
