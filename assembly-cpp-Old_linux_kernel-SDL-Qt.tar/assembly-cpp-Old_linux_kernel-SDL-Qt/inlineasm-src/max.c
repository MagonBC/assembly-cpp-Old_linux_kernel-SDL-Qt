/* 
*	max.c
*
* Issam Abdallah, Information Engineer, Tunisia.
* Email: iabdallah@yandex.com
* Web site: issamabd.com
*/


#include <stdio.h> 
#include "max.h"

int main (void)
{
 int a = 10;
 int b = 5;
 printf("max(%d, %d) = %d\n",a, b, max(a,b));
 return 0;
}

